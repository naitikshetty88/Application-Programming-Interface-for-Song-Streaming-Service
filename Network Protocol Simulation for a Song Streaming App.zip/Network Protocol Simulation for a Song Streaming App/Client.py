#CS 6431 Computer Networks Homework 1
#Name: Naitik Shetty
#GW id: G26859345
#Date – 09/27/2024


import Request
import socket
import time

HOST = '127.0.0.1'
PORT = 12000

def Duration(response):
    last_char = response.split()[-1]
    try:
        duration = int(last_char)
        return duration
    except ValueError:
        duration = 1
        return duration

def run_client():
    # Connect to the server
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        try:
            client_socket.connect((HOST, PORT))
            client_ip = client_socket.getsockname()[0]
            server_ip = HOST
            print("Connection to server: Successful")
        except Exception as e:
            print(f"Connection to server: Unsuccessful: {e}")
            return
        while True:
            def Menu():#Initial command menu
                print("Select:")
                print("1. Open Song Catalog")
                print("2. Open Playlist")
                print("3. Quit Application")
                try:
                    choice = int(input("Enter your choice: "))
                except ValueError:
                    print("Invalid input. Please enter a number.")
                if choice == 1:
                    response = Request.send_request(client_socket, "GET", client_ip=client_ip, server_ip=server_ip)
                    print(response)
                elif choice == 2:
                    Playlist()
                elif choice == 3:
                    response = Request.send_request(client_socket, "CLOSE", client_ip=client_ip, server_ip=server_ip)
                    print(response)
                    client_socket.close()
                else:
                    print("Invalid choice. Please enter a number between 1 and 3.")
            def Playlist():
                print("Choose Mode")
                print("1. Design Mode")
                print("2. Play Mode")
                print("3. Return")
                try:
                    choice = int(input("Enter your choice: "))
                except ValueError:
                    print("Invalid input. Please enter a number.")
                if choice == 1:
                    Design_Mode()
                elif choice == 2:
                    Play_Mode()
                else:
                    Menu()    
            def Mode_Button():
                print("1. Play Next Song")
                print("2. Play Last Song")
                
            def Play_Mode():
                print("Play Menu:")
                print("1. Default")
                print("2. Shuffle")
                print("3. Loop")
                print("4. Stop and Switch to Design Mode")
                print("5. Quit")
                try:
                    choice = int(input("Enter your choice: "))
                except ValueError:
                    print("Invalid input. Please enter a number.")
                if choice == 1:
                    response = Request.send_request(client_socket,"DEFAULT", client_ip=client_ip, server_ip=server_ip)
                    print("Response:", response)
                    while True:
                        print("Skip Song (y/n)")
                        choice = input()
                        if choice == "y":
                            Mode_Button()
                            try:
                                choice = int(input("Enter your choice: "))
                            except ValueError:
                                print("Invalid input. Please enter a number.")
                                continue
                            if choice == 1:
                                response = Request.send_request(client_socket,"NEXT", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                continue
                            elif choice == 2:
                                response = Request.send_request(client_socket,"LAST", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                continue
                            else:
                                print("Invalid Input")
                                continue
                        else:
                            song_time=Duration(response)
                            start = time.time()
                            while time.time() - start < song_time:
                                #Messages through UDP
                                clientSocketUDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
                                response = Request.send_requestUDP(clientSocketUDP,"SONG_DATA_UDP", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                # This method will send repeated messages using TCP. Unhash and run for demonstration
                                #response = Request.send_request(client_socket,"SONG_DATA", client_ip=client_ip, server_ip=server_ip) 
                                #print("Response:", response)
                                time.sleep(2)
                            response = Request.send_request(client_socket,"NEXT", client_ip=client_ip, server_ip=server_ip)
                            print("Response:", response)
                            if response == "Playlist is empty":
                                break
                            elif response == "Playlist has only 1 song":
                                break
                elif choice == 2:
                    response = Request.send_request(client_socket,"SHUFFLE", client_ip=client_ip, server_ip=server_ip)
                    print("Response:", response)
                    while True:
                        print("Skip Song (y/n)")
                        choice = input()
                        if choice == "y":
                            Mode_Button()
                            try:
                                choice = int(input("Enter your choice: "))
                            except ValueError:
                                print("Invalid input. Please enter a number.")
                                continue
                            if choice == 1:
                                response = Request.send_request(client_socket,"SHUFFLE_NEXT", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                continue
                            elif choice == 2:
                                response = Request.send_request(client_socket,"SHUFFLE_LAST", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                continue
                            else:
                                print("Invalid Input")
                                continue
                        else:
                            song_time=Duration(response)
                            start = time.time()
                            while time.time() - start < song_time:
                                #Messages through UDP
                                clientSocketUDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
                                response = Request.send_requestUDP(clientSocketUDP,"SONG_DATA_UDP", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                # This method will send repeated messages using TCP. Unhash and run for demonstration
                                #response = Request.send_request(client_socket,"SONG_DATA", client_ip=client_ip, server_ip=server_ip)
                                #print("Response:", response)
                                time.sleep(2)
                            response = Request.send_request(client_socket,"SHUFFLE_NEXT", client_ip=client_ip, server_ip=server_ip)
                            print("Response:", response)
                            if response == "Playlist is empty":
                                break
                            elif response == "Playlist has only 1 song":
                                break
                elif choice == 3:
                    response = Request.send_request(client_socket,"LOOP", client_ip=client_ip, server_ip=server_ip)
                    print("Response:", response)
                    while True:
                        print("Skip Song (y/n)")
                        choice = input()
                        if choice == "y":
                            Mode_Button()
                            try:
                                choice = int(input("Enter your choice: "))
                            except ValueError:
                                print("Invalid input. Please enter a number.")
                                continue
                            if choice == 1:
                                response = Request.send_request(client_socket,"LOOP_NEXT", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                continue
                            elif choice == 2:
                                response = Request.send_request(client_socket,"LOOP_LAST", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                continue
                            else:
                                print("Invalid Input")
                                continue
                        else:
                            song_time=Duration(response)
                            start = time.time()
                            while time.time() - start < song_time:
                                #Messages through UDP
                                clientSocketUDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
                                response = Request.send_requestUDP(clientSocketUDP,"SONG_DATA_UDP", client_ip=client_ip, server_ip=server_ip)
                                print("Response:", response)
                                # This method will send repeated messages using TCP. Unhash and run for demonstration
                                #response = Request.send_request(client_socket,"SONG_DATA", client_ip=client_ip, server_ip=server_ip)
                                #print("Response:", response)
                                time.sleep(2)
                            response = Request.send_request(client_socket,"LOOP_NEXT", client_ip=client_ip, server_ip=server_ip)
                            print("Response:", response)
                            if response == "Playlist is empty":
                                break
                            elif response == "Playlist has only 1 song":
                                break
                elif choice == 4:
                    Design_Mode()
                            
                else:
                    response = Request.send_request(client_socket, "CLOSE", client_ip=client_ip, server_ip=server_ip)
                    print(response)
                    client_socket.close()
                    
            def Design_Mode():
                print("Design Menu:")
                print("1. Open Song Catalog")
                print("2. Open Playlist")
                print("3. Add Song")
                print("4. Remove Song")
                print("5. Find Song in Playlist")
                print("6. Switch to Play Mode")
                print("7. Quit")
                try:
                    choice = int(input("Enter your choice: "))
                except ValueError:
                    print("Invalid input. Please enter a number.")
                if choice == 1:
                    response = Request.send_request(client_socket, "GET", client_ip=client_ip, server_ip=server_ip)
                    print(response)
                elif choice == 2:
                    response = Request.send_request(client_socket, "GET_LIST", client_ip=client_ip, server_ip=server_ip)
                    print(response)
                elif choice == 3:
                    try:
                        song_id = input("Enter song ID to add to playlist: ")
                    except ValueError:
                        print("Invalid input. Please enter a number.")
                    response = Request.send_request(client_socket,f"ADD {song_id}", client_ip=client_ip, server_ip=server_ip)
                    print("Response:", response)
                elif choice == 4:
                    try:
                        song_id = input("Enter song ID to remove from playlist: ")
                    except ValueError:
                        print("Invalid input. Please enter a number.")
                    response = Request.send_request(client_socket,f"REMOVE {song_id}", client_ip=client_ip, server_ip=server_ip)
                    print("Response:", response)
                elif choice == 5:
                    try:
                        song_id = input("Enter song ID to find in the playlist: ")
                    except ValueError:
                        print("Invalid input. Please enter a number.")
                    response = Request.send_request(client_socket,f"FIND {song_id}", client_ip=client_ip, server_ip=server_ip)
                    print("Response:", response)
                elif choice == 6:
                        Play_Mode()
                else:
                    response = Request.send_request(client_socket, "CLOSE", client_ip=client_ip, server_ip=server_ip)
                    print(response)
                    client_socket.close()
            Menu()
            
def Main():#Runs the client
   run_client()

Main()