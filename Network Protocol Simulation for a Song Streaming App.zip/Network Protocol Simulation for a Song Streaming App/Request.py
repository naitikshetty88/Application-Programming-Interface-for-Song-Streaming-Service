#CS 6431 Computer Networks Homework 1
#Name: Naitik Shetty
#GW id: G26859345
#Date – 09/27/2024

import datetime

# Function to build headers with timestamp, IP addresses, and other metadata
def build_header(message_type, client_ip, server_ip, content_length=0):
    timestamp = datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S GMT')
    header = (f"Message-Type: {message_type}\r\n"f"Client-IP: {client_ip}\r\n"f"Server-IP: {server_ip}\r\n"f"Content-Length: {content_length}\r\n"f"Timestamp: {timestamp}\r\n")
    return header

# Function to send commands to the server and receive responses
def send_request(client_socket, message_type, message_body="", client_ip="127.0.0.1", server_ip="127.0.0.1"):
    header = build_header(message_type, client_ip, server_ip, len(message_body))
    request = header + "\r\n" + message_body
    try:
        client_socket.send(request.encode())
        response = client_socket.recv(1024).decode()
        return response
    except Exception as e:
        return f"Error: {e}"
    
def send_requestUDP(clientSocketUDP, message_type, message_body="", client_ip="127.0.0.1", server_ip="127.0.0.1"):
    header = build_header(message_type, client_ip, server_ip, len(message_body))
    request = header + "\r\n" + message_body
    try:
        clientSocketUDP.sendto(request.encode(),(client_ip,12000))
        response, server_ip = clientSocketUDP.recvfrom(1024)
        response = response.decode()
        return response
    except Exception as e:
        return f"Error: {e}"