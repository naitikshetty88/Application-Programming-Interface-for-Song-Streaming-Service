#CS 6431 Computer Networks Homework 1
#Name: Naitik Shetty
#GW id: G26859345
#Date – 09/27/2024
import socket
import json
import Response
import threading

HOST = '127.0.0.1'
PORT = 12000
CATALOG_FILE = 'database.json'

# Loads the song catalog from the JSON file
def load_catalog():
    with open(CATALOG_FILE, 'r') as file:
        catalog = json.load(file)
    return catalog['catalog']

# Main server function
def run_server():
    catalog = load_catalog()  # Load catalog from JSON file
    print("Song catalog loaded.")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen()

        print(f"TCP Server is listening on {HOST}:{PORT}")
        while True:
            connectionSocket, addr = server_socket.accept()
            Response.handle_client(connectionSocket, addr, catalog)

def run_serverUDP():
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    serverSocket.bind(('', PORT))
    print( "The UDP server is ready to receive: " )
    while(True):
        
        Response.handle_clientUDP(serverSocket)
        

def Main():
    tcp_thread = threading.Thread(target=run_server)
    udp_thread = threading.Thread(target=run_serverUDP)
    tcp_thread.start()
    udp_thread.start()

    tcp_thread.join()
    udp_thread.join()

Main()