#CS 6431 Computer Networks Homework 1
#Name: Naitik Shetty
#GW id: G26859345
#Date – 09/27/2024
import datetime
import random
HOST = '127.0.0.1'
PORT = 12000

# Function to build headers
def build_header(response_type, client_ip, server_ip, content_length=0):
    timestamp = datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S GMT')
    header = (f"Message-Type: {response_type}\r\n"f"Client-IP: {client_ip}\r\n"f"Server-IP: {server_ip}\r\n"f"Content-Length: {content_length}\r\n"f"Timestamp: {timestamp}\r\n")
    return header

# Function to handle client requests
def handle_client(connectionSocket, addr, catalog):
    print(f"Connected by {addr}")
    client_ip = addr[0]
    server_ip = HOST
    

    playlist = []  # Initialize an empty playlist
    playlist_temp = []
    now_playing = []
    play_next = []
    play_previous = []
    while True:
        try:
            data = connectionSocket.recv(1024).decode()
            if not data:
                break

            print(f"Received data: {data}")
            request_lines = data.split("\r\n")
            request_type = request_lines[0].split(": ")[1].strip()  # Extract the message type
            
            if request_type == "GET":
                catalog_data_response=""
                for song in catalog:
                    catalog_data_response += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                header = build_header("GET_RESPONSE", client_ip, server_ip, len(catalog_data_response))
                response = header + "\r\n" + catalog_data_response
                connectionSocket.send(response.encode())

            elif request_type.startswith("ADD"):
                parts = request_type.split()
                if len(parts) > 1:  # Ensure there is a song ID provided
                    try:
                        song_id = int(parts[1])  # Converts song ID to integer
                        for song in catalog:
                            if song['id'] == song_id:
                                playlist.append(catalog[song_id])  # Append the song directly
                                response = "Song added to playlist."
                                break
                            else:
                                response = f"Song with ID {song_id} not found."
                    except ValueError:
                        response = "Invalid song ID format. Please provide a numeric ID."
                else:
                    response = "No song ID provided. Please specify an ID to add a song."
 
                header = build_header("ADD_RESPONSE", client_ip, server_ip, len(response))
                connectionSocket.send((header + "\r\n" + response).encode())

            elif request_type == "GET_LIST":
                playlist_data = ""
                for song in playlist:
                    playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
    
                header = build_header("GET_LIST_RESPONSE", client_ip, server_ip, len(playlist_data))
                if len(playlist_data) == 0:
                    response = "Playlist is empty"
                else:
                    response = header + "\r\n" + playlist_data
                connectionSocket.send(response.encode())

            elif request_type.startswith("REMOVE"):
                parts = request_type.split()
                if len(parts) > 1:  # Ensure there is a song ID provided
                    try:
                        song_id = int(parts[1])  # Converts song ID to integer
                        for song in playlist:
                            if song['id'] == song_id:
                                playlist.remove(song)  # Append the song directly
                                response = "Song removed from playlist."
                                break
                            else:
                                response = f"Song with ID {song_id} not found."
                    except ValueError:
                        response = "Invalid song ID format. Please provide a numeric ID."
                else:
                    response = "No song ID provided. Please specify an ID to add a song."
 
                header = build_header("REMOVE_RESPONSE", client_ip, server_ip, len(response))
                connectionSocket.send((header + "\r\n" + response).encode())
            
            elif request_type.startswith("FIND"):
                parts = request_type.split()
                if len(parts) > 1:  # Ensure there is a song ID provided
                    try:
                        song_id = int(parts[1])  # Converts song ID to integer
                        for song in playlist:
                            if song['id'] == song_id:
                                response = "Song Found"+"\r\n"+f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                                break
                            else:
                                response = f"Song with ID {song_id} not found."
                    except ValueError:
                        response = "Invalid song ID format. Please provide a numeric ID."
                else:
                    response = "No song ID provided. Please specify an ID to add a song."
 
                header = build_header("FIND_RESPONSE", client_ip, server_ip, len(response))
                connectionSocket.send((header + "\r\n" + response).encode())

            elif request_type == "CLOSE":
                response = "Closing connection."
                header = build_header("CLOSE_RESPONSE", client_ip, server_ip, len(response))
                connectionSocket.send((header + "\r\n" + response).encode())
                connectionSocket.close()
                break
            elif request_type == "DEFAULT":               
                if len(playlist) == 0:
                    response = "Playlist is empty"
                    connectionSocket.send(response.encode())
                else:          
                    playlist_temp = playlist.copy()
                    now_playing.append(playlist_temp[0])
                    playlist_temp.pop(0)
                    play_next = playlist_temp
                    playlist_data = ""
                    now_data = ""
                    for song in playlist:
                        playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    for song in now_playing:
                        now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    header = build_header("DEFAULT_RESPONSE", client_ip, server_ip, len(playlist_data))
                    response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                    connectionSocket.send(response.encode())
            elif request_type == "NEXT":
                if len(playlist) == 0 and len(playlist_temp) == 0:
                    response = "Playlist is empty"
                else:
                    play_previous.append(now_playing)
                    now_playing = []
                    if len(playlist_temp)==0:
                        response = "Playlist is empty"
                    elif len(play_next)==0:
                        response = "Playlist has only 1 song"
                    else:
                        now_playing.append(playlist_temp[0])
                        playlist_temp.pop(0)
                        play_next = playlist_temp
                        playlist_data = ""
                        now_data = ""
                        for song in playlist:
                            playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        for song in now_playing:
                            now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        header = build_header("NEXT_RESPONSE", client_ip, server_ip, len(playlist_data))
                        response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                connectionSocket.send(response.encode())
            elif request_type == "LAST":
                if len(playlist) == 0 and len(playlist_temp) == 0:
                    response = "Playlist is empty"
                elif len(play_previous)==0:
                    response = "This is the first Song"
                else:
                    playlist_temp.insert(0,now_playing[0])
                    now_playing = []
                    now_playing.append(play_previous.pop())
                    play_next = playlist_temp
                    playlist_data = ""
                    now_data = ""
                    for song in playlist:
                        playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    for song in now_playing:
                        now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    header = build_header("LAST_RESPONSE", client_ip, server_ip, len(playlist_data))
                    response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                connectionSocket.send(response.encode())
            elif request_type == "SHUFFLE":               
                if len(playlist) == 0:
                    response = "Playlist is empty"
                    header = build_header("SHUFFLE_RESPONSE", client_ip, server_ip, len(response))
                    response = header + "\r\n" + response
                    connectionSocket.send(response.encode())
                else:
                    shuffled_list = random.sample(playlist, len(playlist))             
                    playlist_temp = shuffled_list.copy()
                    now_playing.append(playlist_temp[0])
                    playlist_temp.pop(0)
                    play_next = playlist_temp
                    playlist_data = ""
                    now_data = ""
                    for song in shuffled_list:
                        playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    for song in now_playing:
                        now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        header = build_header("SHUFFLE_RESPONSE", client_ip, server_ip, len(playlist_data))
                        response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                    connectionSocket.send(response.encode())
            elif request_type == "SHUFFLE_NEXT":
                if len(playlist) == 0 and len(playlist_temp) == 0:
                    response = "Playlist is empty"
                else:
                    play_previous.append(now_playing)
                    now_playing = []
                    if len(playlist_temp)==0:
                        response = "Playlist is empty"
                    elif len(play_next)==0:
                        response = "Playlist has only 1 song"
                    else:
                        now_playing.append(playlist_temp[0])
                        playlist_temp.pop(0)
                        play_next = playlist_temp
                        playlist_data = ""
                        now_data = ""
                        for song in shuffled_list:
                            playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        for song in now_playing:
                            now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        header = build_header("SHUFFLE_NEXT_RESPONSE", client_ip, server_ip, len(playlist_data))
                        response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                connectionSocket.send(response.encode())
            elif request_type == "SHUFFLE_LAST":
                if len(playlist) == 0 and len(playlist_temp) == 0:
                    response = "Playlist is empty"
                elif len(play_previous)==0:
                    response = "This is the first Song"
                else:
                    playlist_temp.insert(0,now_playing[0])
                    now_playing = []
                    now_playing.append(play_previous.pop())
                    play_next = playlist_temp
                    playlist_data = ""
                    now_data = ""
                    for song in shuffled_list:
                        playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    for song in now_playing:
                        now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    header = build_header("SHUFFLE_LAST_RESPONSE", client_ip, server_ip, len(playlist_data))
                    response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                connectionSocket.send(response.encode())
            elif request_type == "LOOP":               
                if len(playlist) == 0:
                    response = "Playlist is empty"
                    header = build_header("LOOP_RESPONSE", client_ip, server_ip, len(response))
                    response = header + "\r\n" + response
                    connectionSocket.send(response.encode())
                else:
                    now_playing = []             
                    playlist_temp = playlist.copy()
                    now_playing.append(playlist_temp[0])
                    playlist_temp.pop(0)
                    play_next = playlist_temp
                    playlist_data = ""
                    now_data = ""
                    for song in playlist:
                        playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    for song in now_playing:
                        now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        header = build_header("LOOP_RESPONSE", client_ip, server_ip, len(playlist_data))
                        response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                    connectionSocket.send(response.encode())
                    playlist_temp.append(now_playing[0])
            elif request_type == "LOOP_NEXT":
                if len(playlist) == 0 and len(playlist_temp) == 0:
                    response = "Playlist is empty"
                else:
                    play_previous.append(now_playing[0])
                    now_playing = []
                    if len(playlist_temp)==0:
                        response = "Playlist is empty"
                    elif len(play_next)==0:
                        response = "Playlist has only 1 song"
                    else:
                        now_playing.append(playlist_temp[0])
                        playlist_temp.pop(0)
                        play_next = playlist_temp
                        playlist_data = ""
                        now_data = ""
                        for song in playlist:
                            playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        for song in now_playing:
                            now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        header = build_header("LOOP_NEXT_RESPONSE", client_ip, server_ip, len(playlist_data))
                        response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data
                        playlist_temp.append(now_playing[0]) 
                connectionSocket.send(response.encode())
            elif request_type == "LOOP_LAST":
                if len(playlist) == 0 and len(playlist_temp) == 0:
                    response = "Playlist is empty"
                elif len(play_previous)==0:
                    if len(playlist_temp)==0:
                        playlist_temp=now_playing
                        now_playing=[]
                        now_playing=playlist_temp
                        playlist_data = ""
                        now_data = ""
                        for song in playlist:
                            playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        for song in now_playing:
                           now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    else:
                        now_playing.append(playlist_temp.pop())
                        playlist_data = ""
                        now_data = ""
                        for song in playlist:
                            playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                        for song in now_playing:
                           now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    header = build_header("LOOP_LAST_RESPONSE", client_ip, server_ip, len(playlist_data))
                    response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data
                    playlist_temp.append(now_playing[0]) 
                else:
                    playlist_temp.insert(0,now_playing[0])
                    now_playing = []
                    now_playing.append(play_previous.pop())
                    play_next = playlist_temp
                    playlist_data = ""
                    now_data = ""
                    for song in playlist:
                        playlist_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    for song in now_playing:
                        now_data += f"{song['id']} {song['song_title']} {song['artist']} {song['album']} {song['duration']}"+"\r\n"
                    header = build_header("LOOP_LAST_RESPONSE", client_ip, server_ip, len(playlist_data))
                    response = header + "\r\n" + playlist_data + "\r\n" + "Now Playing : " + now_data 
                connectionSocket.send(response.encode())
                playlist_temp.append(now_playing[0]) 
            elif request_type == "SONG_DATA":
                response = "song data .... song data"
                header = build_header("SONG_DATA_RESPONSE", client_ip, server_ip, len(response))
                response = header + " " + response
                connectionSocket.send(response.encode())
            

        except Exception as e:
            print(f"Error: {e}")
            break

    
    print(f"Connection closed with {addr}")

def handle_clientUDP(serverSocket): 
    server_ip = HOST
    while True:
        try:
            data1, client_ip  = serverSocket.recvfrom(2048)
            data1=data1.decode()
            if not data1:
                break

            print(f"Received data: {data1}")
            request_lines1 = data1.split("\r\n")
            request_type1 = request_lines1[0].split(": ")[1].strip()  # Extract the message type
            if request_type1 == "SONG_DATA_UDP":
                response = "song data UDP .... song data UDP"
                header = build_header("SONG_DATA_RESPONSE_UDP", client_ip, server_ip, len(response))
                response = header + " " + response
                serverSocket.sendto(response.encode(),client_ip)

        except Exception as e:
            print(f"Error: {e}")
            break
 